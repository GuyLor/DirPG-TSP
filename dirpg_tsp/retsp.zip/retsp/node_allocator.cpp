#include "node_allocator.h"

#include "assert.h"

#include "mst_node.h"
#include "gumbels_state.h"
#include "info_node.h"

template<typename T>
NodeAllocator<T>::NodeAllocator(int max_num_nodes, int graph_size) {
  nodes_.resize(max_num_nodes);
  is_allocated_.resize(max_num_nodes);
  next_to_allocate_ = 0;
  max_num_nodes_ = max_num_nodes;

  for (int i = 0; i < max_num_nodes; i++) {
    nodes_[i] = new T(graph_size);
  }
}

template<typename T>
NodeAllocator<T>::~NodeAllocator() {
  for (int i = 0; i < max_num_nodes_; i++) {
    delete nodes_[i];
  }
 }

template<typename T>
T *NodeAllocator<T>::getNew() {
  assert(next_to_allocate_ < max_num_nodes_);
  is_allocated_[next_to_allocate_] = true;
  return nodes_[next_to_allocate_++];
}


template<typename T>
void NodeAllocator<T>::clear() {
  /* Set state so we can allocate anything, but don't bother clearing nodes_.
   *
   * If there are dangling pointers to nodes that have been previously allocated
   * then the memory will stay in tact, but it might get overridden with new
   * nodes.
   */
  fill(is_allocated_.begin(), is_allocated_.end(), false);
  next_to_allocate_ = 0;
}


MstNode *NodeAllocator::split(MstNode *parent, int special_child) {
  // Modifies `parent` in place. Assumes it's not needed any more.
  MstNode *other_children_node = parent;

  MstNode *special_child_node = getNew<MstNode>();
  special_child_node->CopyState(parent);

  special_child_node->transformToSpecialChild(special_child);
  other_children_node->transformToOtherChildren(special_child);

  return special_child_node;
}

GumbelState *NodeAllocator::split(GumbelState *parent_gumbel, MstNode *parent_mst, int special_action, torch::Tensor logprobs) {
  // Modifies `parent` in place. Assumes it's not needed any more.
  GumbelState *other_children_node = parent_gumbel;

  GumbelState *special_child_node = getNew<GumbelState>();
  special_child_node->CopyState(parent_gumbel);

  special_child_node->transformToSpecialChild(special_action, logprobs);
  other_children_node->transformToOtherChildren(special_action, logprobs, parent_mst);

  return special_child_node;
}

InfoNode *NodeAllocator::split(InfoNode *parent, int special_child) {
  // Modifies `parent` in place. Assumes it's not needed any more.
  InfoNode *other_children_node = parent;

  InfoNode *special_child_node = getNew<InfoNode>();
  special_child_node->CopyState(parent);

  special_child_node->transformToSpecialChild(special_child);
  other_children_node->transformToOtherChildren(special_child);

  return special_child_node;
}