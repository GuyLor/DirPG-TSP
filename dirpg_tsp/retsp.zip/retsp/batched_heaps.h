#ifndef BATCHED_HEAPS_H__
#define BATCHED_HEAPS_H__
#include <torch/extension.h>
#include <vector>
#include "mst_node.h"
#include "info_node.h"
#include "gumbels_state.h"
using namespace std;

struct OuterNode{

    GumbelState *gumbel_node;  // attrs: max_gumbel_, logprob_so_far_
    MstNode *mst_node;   // attrs: visited_mask_, legal_next_action_mask_, first_node_, last_node_
    InfoNode *info_node;

    OuterNode(){
    }

    void copyState(const OuterNode *other_node) {
      gumbel_node = other_node->gumbel_node;
      mst_node = other_node->mst_node;
      info_node = other_node->info_node;
    }
    void setNodes(GumbelState *gumbel_node_, MstNode *mst_node_, InfoNode *info_node_){
        gumbel_node = gumbel_node_;
        mst_node = mst_node_;
        info_node = info_node_;
    }
};

struct HeapNode {
    float priority;
    bool t_opt;
    bool done;
    OuterNode outer_node;

    ~HeapNode(){}
    HeapNode(float priority_, OuterNode outer_node_, bool done_)
    :
    priority(priority_), t_opt(outer_node_.info_node -> getIsTopt()), done(done_), outer_node(outer_node_)
    {}
    HeapNode(const HeapNode &other){
        priority = other.priority;
        t_opt = other.t_opt;
        done = other.done;
        outer_node = other.outer_node;
    }

    bool operator<(const HeapNode &other) const {
         if (t_opt == other.t_opt){
            return priority < other.priority;
         }
         if (t_opt && !other.t_opt){
            return false;
         }
         else{
            return true;
         }
    }
};

class Heap {
    public:
        Heap(){};
        void push(HeapNode new_node) {

            elements_.push_back(new_node);
            push_heap(elements_.begin(), elements_.end());
        }

        HeapNode pop() {
            HeapNode result = elements_.front();
            pop_heap(elements_.begin(), elements_.end());

            elements_.pop_back();
            return result;
        }

        bool is_empty() {
            return elements_.empty();
        };

    protected:
        std::vector<HeapNode> elements_;
};

struct BatchedTrajectories{
    torch::Tensor costs;
    torch::Tensor objectives;
    torch::Tensor actions;
    int num_candidates;

    BatchedTrajectories(int batch_size, int graph_size){
        costs = torch::empty(batch_size, torch::kFloat32);
        objectives = torch::empty(batch_size, torch::kFloat32);
        actions = torch::empty({batch_size, graph_size}, torch::kInt32);
    }

    void setTrajectory(int idx, float objective, OuterNode node){
        num_candidates += 1;
        if (num_candidates == 1){
            costs[idx] = node.info_node -> getCost();
            //actions[idx] = node.info_node -> getActions();
            auto opts = torch::TensorOptions().dtype(torch::kInt32);
            actions[idx] = torch::from_blob((node.info_node -> getActions()).data(), {actions.size(1)}, opts);
            objectives[idx] = objective;

        }
        else if (objective > objectives[idx].item<float>()){
            costs[idx] = node.info_node -> getCost();
            //actions[idx] = node.info_node -> getActions();
            auto opts = torch::TensorOptions().dtype(torch::kInt32);
            actions[idx] = torch::from_blob((node.info_node -> getActions()).data(), {actions.size(1)}, opts);
            objectives[idx] = objective;
        }
    }
};

class BatchedHeaps{
    public:
        BatchedHeaps();

        HeapNode pop(int sample_idx, BatchedTrajectories &trajectories);
        void push(int sample_idx, OuterNode outer_node, float priority);

    protected:
        int batch_size_ = 100;
        vector<Heap> heaps_;

   };

#endif