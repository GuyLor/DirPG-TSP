/* A search node that only stores information needed by the c++ side.
 *
 * We need information to compute spanning trees and to split CppNodes.
 * Otherwise, don't put the data into here.
 */

#ifndef GUMBEL_STATE_H__
#define GUMBEL_STATE_H__

#include <vector>

using namespace std;


class GumbelState {

 public:
  GumbelState(int graph_size);

  void CopyState(const GumbelState *other_node);


  // Print out state, just for debugging.
  void dump() const;

  // Expansions. We'll re-use memory when possible, so define expansion in terms
  // of converting existing nodes into the new ones we need.
  void transformToSpecialChild(int special_child);
  void transformToOtherChildren(int special_child);
  float getMaxGumbel();


 protected:


  int graph_size_;


  float max_gumbel_;
  float logprob_so_far_;

};


#endif  // CPP_NODE_H__
