#include "a_star_sampling.h"

#include <torch/extension.h>



AstarSampling::AstarSampling(int batch_size, int search_budget, int graph_size){
  mst_node_allocator_ = NodeAllocator<MstNode>(batch_size*search_budget, graph_size);
  gumbel_node_allocator_ = NodeAllocator<GumbelState>(batch_size*search_budget, graph_size);
  info_node_allocator_ = NodeAllocator<InfoNode>(batch_size*search_budget, graph_size);
  graph_size_ = graph_size;
  batch_size_ = batch_size;

  heaps_ = BatchedHeaps(batch_size_);
  graphs_ = BatchedGraphs(batch_size_, graph_size_);
  trajectories_ = BatchedTrajectories(batch_size_, graph_size_);
}

float AstarSampling::computePriority(OuterNode outer_node, int idx){
 return outer_node.gumbel_node -> getMaxGumbel() + epsilon_*(outer_node.info_node -> getCost() + graphs_.mstCost(idx, outer_node.mst_node))
}

OuterNode AstarSampling::split(OuterNode &outer_node,
                               int special_action,
                               float cost,
                               torch::Tensor logprobs){
    MstNode *other_child_mst = outer_node.mst_node;
    MstNode *special_child_mst = mst_node_allocator_.split(other_child_mst,
                                                           special_action);

    GumbelState *other_child_gumbel = outer_node.gumbel_node;
    GumbelState *special_child_gumbel = gumbel_node_allocator_.split(other_child_gumbel,
                                                                     other_child_mst,
                                                                     special_action,
                                                                     logprobs);

    InfoNode *other_child_info = outer_node.info_node;
    InfoNode *special_child_info = info_node_allocator_.split(other_child_info,
                                                              special_action,
                                                              cost,
                                                              done);

    outer_node.setAttrs(other_child_mst, other_child_gumbel, other_child_info);

    OuterNode special_outer = OuterNode();
    special_outer.setAttrs(special_child_mst, special_child_gumbel, special_child_info);
    return special_outer;
}

void AstarSampling::expand(torch::Tensor batch_special_action,
                           torch::Tensor batch_logprobs,
                           torch::Tensor batch_reward,
                           torch::Tensor batch_done,
                           vector<OuterNode> batch_outer_node){

    for (int sample_idx=0; sample_idx < batch_size_; sample_idx++){
        OuterNode special_outer = split(outer_node,
                                        batch_special_action[sample_idx].item<int>(),
                                        batch_reward[sample_idx].item<float>(),
                                        batch_logprobs[sample_idx]);
        heaps_.push(sample_idx, special_outer, computePriority(special_outer), batch_done[sample_idx].item<bool>());
        heaps_.push(sample_idx, outer_node, computePriority(outer_node), batch_done[sample_idx].item<bool>());
    }
}

EnvInfo AstarSampling::popBatch(){
    EnvInfo to_return(batch_size_, graph_size_);
    for (int sample_idx=0; sample_idx < batch_size_; sample_idx++){
        OuterNode node(heaps_[sample_idx].pop().outer_node);
        to_return.batch_t[sample_idx] = (node -> info_node).getT();
        to_return.batch_prev_city[sample_idx] = (node -> mst_node).getPrevCity();
        to_return.batch_next_actions[sample_idx] = (node -> mst_node).getLegalNextActionMask();
        to_return.nodes.push_back(node);
    }
    return to_return;
}

void AstarSampling::initialize(torch::Tensor batch_start_city, torch::Tensor weights){
    for (int sample_idx=0; sample_idx < batch_size_){
        MstNode *mst_node = mst_node_allocator.getNew(); // root
        GumbelState *gumbel_node = gumbel_node_allocator.getNew(); // root
        InfoNode *info_node = gumbel_node_allocator.getNew(); // root

        int start_city = batch_start_city[sample_idx].item<int>()
        bool visited_mask0[graph_size_] = { false };
        visited_mask0[start_city] = true;

        bool legal_next_action_mask0[graph_size_] = { true };
        legal_next_action_mask0[start_city] = false;

        mst_node->setVisitedMask(visited_mask0);
        mst_node->setLegalNextActionMask(legal_next_action_mask0);
        mst_node->setFirstLast(start_city, start_city);

        OuterNode outer_node = OuterNode();
        outer_node.setNodes(gumbel_node, mst_node, info_node);
        // fill graphs
        float dm[2*graph_size_];
        for(int idx=0; idx < 2*graph_size_; idx++){
            dm[idx] = weights[i][idx].item<float>();
        }
        graphs_.setWeights(sample_idx, dm);
        heaps_.push(sample_idx, outer_node, computePriority(outer_node), false);
    }
}

}