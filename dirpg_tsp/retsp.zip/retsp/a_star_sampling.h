#ifndef A_STAR_SAMPLING_H__
#define A_STAR_SAMPLING_H__

#include <vector>

#include "batched_graphs.h"
#include "batched_heaps.h"

#include "mst_node.h"
#include "info_node.h"
#include "gumbels_state.h"

#include "node_allocator.h"
using namespace std;


// struct EnvInfo;
//struct BatchedTrajectories;
//struct OuterNode;

struct EnvInfo{
    torch::Tensor batch_t;
    torch::Tensor batch_prev_city;
    torch::Tensor batch_next_actions;
    vector<OuterNode> nodes;

    EnvInfo(int batch_size, int graph_size){
        batch_t = torch::empty(batch_size, torch::kInt64);
        batch_prev_city = torch::empty(batch_size, torch::kInt64);
        batch_next_actions = torch::empty({batch_size, graph_size}, torch::kUInt8);
    }
};

class AstarSampling {
 public:
  AstarSampling(int batch_size, int search_budget, int graph_size);
  void initialize(torch::Tensor batch_start_city, torch::Tensor weights);
  void expand(torch::Tensor batch_special_action,
              torch::Tensor batch_logprobs,
              torch::Tensor batch_reward,
              torch::Tensor batch_done,
              vector<OuterNode> batch_outer_node);
  EnvInfo popBatch();




 protected:

  int graph_size_;
  int batch_size_;

  NodeAllocator<MstNode> mst_node_allocator_;
  NodeAllocator<GumbelState> gumbel_node_allocator_;
  NodeAllocator<InfoNode> info_node_allocator_;

  BatchedHeaps heaps_;
  BatchedGraphs graphs_;
  BatchedTrajectories trajectories_;
};

#endif  // CPP_NODE_H__
