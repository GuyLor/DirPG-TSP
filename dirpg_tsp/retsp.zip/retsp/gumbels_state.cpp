#include "mst_node.h"
#include <random>
#include <numeric>
//#include <iostream>

//namespace py = pybind11;
#include <torch/extension.h>

using namespace torch::indexing

std::default_random_engine generator(666);
std::exponential_distribution<double> expo(1.0);

double sample_gumbel(double location=0.0, double scale=1.0){
    return -log(expo(generator)) + location;
}

double sample_truncated_gumbel(double location, double b){
    //Sample a Gumbel(location) truncated to be less than b
    return -log(expo(generator) + exp(-b + location)) + location;
}

double logsumexp(double arr[], int count){
   if(count > 0 ){
      double maxVal = arr[0];
      double sum = 0;

      for (int i = 1 ; i < count ; i++){
         if (arr[i] > maxVal){
            maxVal = arr[i];
         }
      }

      for (int i = 0; i < count ; i++){
         sum += exp(arr[i] - maxVal);
      }
      return log(sum) + maxVal;
   }
   else
   {
      return 0.0;
   }
}
GumbelState::GumbelState() :
  graph_size_(graph_size)
{

}


void GumbelState::CopyState(const GumbelState *other_node) {
  max_gumbel_ = other_node->max_gumbel_;
  logprob_so_far_ = other_node->logprob_so_far_;
}

void GumbelState::setMaxGumbelLogprobs(float max_gumbel, float logprob_so_far) {
  max_gumbel_ = max_gumbel;
  logprob_so_far_ = logprob_so_far;
}
float GumbelState::getMaxGumbel(){
    return max_gumbel_;
  }
void GumbelState::dump() const {
  py::print("max gumbel: ", max_gumbel_);
  py::print("logprob so far: ", logprob_so_far_);
}

void GumbelState::transformToSpecialChild(int special_action, torch::Tensor logprobs) {
  /* Make this node into a special child of its current values. */
  logprob_so_far_ += logprobs.index({special_action});
}


void GumbelState::transformToOtherChildren(int special_action, torch::Tensor logprobs, MstNode *parent_mst) {
  /* Make this node into the other children of its current values. */
  torch::Tensor next_actions(parent_mst -> getLegalNextActionMask);
  max_gumbel_ = sample_truncated_gumbel(logprob_so_far_ + logsumexp(logprobs.index({next_actions})), max_gumbel_);
}
