
#include "batched_heaps.h"
#include<vector>
using namespace std;


BatchedHeaps::BatchedHeaps(int batch_size){
    batch_size_ = batch_size;
}

HeapNode BatchedHeaps::pop(int sample_idx, BatchedTrajectories &trajectories){
        bool to_pop = true; //!heaps_[sample_idx].is_empty();
        while (to_pop){
            HeapNode node(heaps_[sample_idx].pop());
            to_pop = node.done;
            if(to_pop){
                trajectories.setTrajectory(sample_idx, node.priority, node.outer_node);
            }
            else{
                heap_nodes.push_back(node);
            }
        }
        return node;
    }

void BatchedHeaps::push(int sample_idx, OuterNode outer_node, float priority){
        HeapNode node(priority, outer_node)
        heaps_[sample_idx].push(heap_nodes[sample_idx]);
    }
};
