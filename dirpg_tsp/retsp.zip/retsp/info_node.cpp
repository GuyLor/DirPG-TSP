#include "info_node.h"

#include <random>
#include <numeric>
//#include <iostream>

//namespace py = pybind11;
#include <torch/extension.h>

InfoNode::InfoNode(int graph_size) :
  graph_size_(graph_size)
{
  prefix_.resize(graph_size);
}


void InfoNode::CopyState(const InfoNode *other_node) {
  setPrefix(other_node->prefix_);
  cost_so_far_ = other_node->cost_so_far_;
  t_ = other_node->t_;
  is_t_opt_ = other_node->is_t_opt_;
}


void InfoNode::setPrefix(bool *prefix) {
  // `visited_mask` must be an array of length `graph_size_`.
  copy(prefix, prefix + graph_size_, prefix_.begin());
}

void InfoNode::setPrefix(const vector<bool> &prefix) {
  // `visited_mask` must be an array of length `graph_size_`.
  copy(prefix.begin(), prefix.end(), prefix_.begin());
}

void InfoNode::setCost(float cost) {
  cost_so_far_ = cost;
}

vector<int> InfoNode::getActions(){
    return prefix_;
}
float InfoNode::getCost(){
    return cost_so_far_;
}

bool InfoNode::getIsTopt(){
    return is_t_opt_;
}

bool InfoNode::getIsDone(){
    return done_;
}

int InfoNode::getT(){
    return t_;
}

void InfoNode::dump() const {
  py::print("prefix: ");
  for (const auto &val : prefix_) {
    py::print((bool) val) ;
  }

  py::print("cost_so_far: " ,cost_so_far_);
  py::print("t: " ,t_);
  }

void InfoNode::transformToSpecialChild(int special_child, float cost) {
  /* Make this node into a special child of its current values. */
  prefix_[t_] = special_child;
  t_ += 1;
  cost_so_far_ += cost;
}


void InfoNode::transformToOtherChildren(int special_child) {
    is_t_opt_ = false;
  /* Make this node into the other children of its current values. */
}
